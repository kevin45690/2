namespace WebApi
{
    public class WeatherForecast
    {
        public DateOnly Date { get; set; }

        public int TemperatureC { get; set; }

        public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

        public string? Summary { get; set; }
    }
}
//Scaffold-DbContext "Data Source=Figueroa;Initial Catalog=OperacionesMatematicas;User ID=kevin;Password=8890;Encrypt=False" Microsoft.EntityFrameworkCore.SqlServer -ContextDir "Context" -OutputDir "Models"
